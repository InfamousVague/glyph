"use strict";
(() => {
  // src/popup/popup.ts
  var $ = (id) => document.getElementById(id);
  var send = (msg) => chrome.runtime.sendMessage(msg);
  function say(text, tone = "") {
    const m = $("message");
    if (!text) {
      m.hidden = true;
      return;
    }
    m.hidden = false;
    m.textContent = text;
    m.className = `message${tone ? ` ${tone}` : ""}`;
  }
  function when(at) {
    if (!at) return "";
    const mins = Math.round((Date.now() - at) / 6e4);
    if (mins < 1) return "just now";
    if (mins < 60) return `${mins} min ago`;
    const hrs = Math.round(mins / 60);
    if (hrs < 24) return `${hrs} h ago`;
    return `${Math.round(hrs / 24)} d ago`;
  }
  function render(s) {
    $("signedout").hidden = s.signedIn;
    $("signedin").hidden = !s.signedIn;
    $("signout").hidden = !s.signedIn;
    if (s.error) say(s.error, "bad");
    else if (s.note) say(s.note);
    else say("");
    if (!s.signedIn) return;
    $("who").textContent = s.username ? `@${s.username}` : s.address ?? "Signed in";
    const list = $("services");
    list.innerHTML = "";
    for (const svc of s.services) {
      const li = document.createElement("li");
      li.className = "svc";
      const badge = svc.synced ? `<span class="badge ok">Synced \xB7 ${when(svc.syncedAt)}</span>` : svc.ready ? '<span class="badge">Signed in here</span>' : '<span class="badge off">Not signed in here</span>';
      const actions = svc.ready ? `<button data-sync="${svc.id}">${svc.synced ? "Re-sync" : "Sync now"}</button>${svc.synced ? `<button data-forget="${svc.id}">Stop syncing</button>` : ""}` : `<a href="${svc.signInUrl}" target="_blank" rel="noreferrer">Open ${svc.name} to sign in</a>`;
      li.innerHTML = `<div class="svc-top"><span class="svc-name">${svc.name}</span>${badge}</div><div class="svc-row">${actions}</div>`;
      list.appendChild(li);
    }
    list.querySelectorAll("[data-sync]").forEach(
      (b) => b.addEventListener("click", () => act(() => send({ type: "sync", serviceId: b.dataset.sync }), "Synced."))
    );
    list.querySelectorAll("[data-forget]").forEach(
      (b) => b.addEventListener("click", () => act(() => send({ type: "forget", serviceId: b.dataset.forget }), "Stopped syncing that service."))
    );
  }
  async function act(run, ok) {
    say("Working\u2026");
    try {
      const s = await run();
      render(s);
      if (ok && !s.error) say(ok, "good");
    } catch (e) {
      say(e.message || "Something went wrong.", "bad");
    }
  }
  function tab(which) {
    $("tab-password").classList.toggle("on", which === "password");
    $("tab-words").classList.toggle("on", which === "words");
    $("form-password").hidden = which !== "password";
    $("form-words").hidden = which !== "words";
  }
  $("tab-password").addEventListener("click", () => tab("password"));
  $("tab-words").addEventListener("click", () => tab("words"));
  $("form-password").addEventListener("submit", (e) => {
    e.preventDefault();
    const username = $("username").value.trim();
    const password = $("password").value;
    const code = $("code").value.trim() || void 0;
    const stay = $("stay-p").checked;
    if (!username || !password) return say("Enter your username and password.", "bad");
    act(async () => {
      const s = await send({ type: "signInPassword", username, password, code, stay });
      if (s.needsCode) $("code-row").hidden = false;
      return s;
    });
  });
  $("form-words").addEventListener("submit", (e) => {
    e.preventDefault();
    const words = $("words").value.trim().toLowerCase().split(/[\s,]+/).filter(Boolean);
    const stay = $("stay-w").checked;
    if (words.length < 12) return say("Enter all 12 of your recovery words.", "bad");
    act(() => send({ type: "signInWords", words, stay }));
  });
  $("syncall").addEventListener("click", () => act(() => send({ type: "sync" }), "Captured and synced."));
  $("signout").addEventListener("click", () => act(() => send({ type: "signOut" })));
  act(() => send({ type: "status" }));
})();
